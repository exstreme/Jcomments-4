ALTER TABLE `#__jcomments_blacklist` CHANGE `expire` `expire` DATETIME NULL;
ALTER TABLE `#__jcomments_blacklist` CHANGE `notes` `notes` TINYTEXT CHARSET utf8mb4 COLLATE utf8mb4_unicode_ci NULL;
