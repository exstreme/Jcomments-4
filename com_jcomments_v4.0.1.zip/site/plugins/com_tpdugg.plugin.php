<?php
/**
 * JComments plugin for TPDugg objects support
 *
 * @version 1.0
 * @package JComments
 * @author Sergey M. Litvinov (smart@joomlatune.ru) & exstreme (info@protectyoursite.ru) & Vladimir Globulopolis
 * @copyright (C) 2011-2013 by Sergey M. Litvinov (http://www.joomlatune.ru)
 * @license GNU/GPL: http://www.gnu.org/copyleft/gpl.html
 */

use Joomla\CMS\Factory;

defined('_JEXEC') or die;

class jc_com_tpdugg extends JCommentsPlugin
{
	function getObjectTitle($id)
	{
		$db = Factory::getContainer()->get('DatabaseDriver');
		$db->setQuery("SELECT title, id FROM #__tpdugg WHERE id='$id'");
		return $db->loadResult();
	}
 
	function getObjectLink($id)
	{
		$_Itemid = self::getItemid('com_tpdugg');
		$link = JRoute::_('index.php?option=com_tpdugg&amp;task=detail&amp;id='.$id.'&amp;show=comments'.'&Itemid='. $_Itemid);
		return $link;
	}

	function getObjectOwner($id)
	{
		$db = Factory::getContainer()->get('DatabaseDriver');
		$db->setQuery("SELECT userid FROM #__tpdugg WHERE id='$id'");
		return $db->loadResult();
	}
}